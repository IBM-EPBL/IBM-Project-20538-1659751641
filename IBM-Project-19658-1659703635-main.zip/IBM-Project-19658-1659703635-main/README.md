# IBM Project

## University Admit Eligibility Predictor

### Assignments :

#### Team Lead :
- Jaya Shravan S
    - [Assignment 01](./Assignments/Team%20Lead/Assignment-01/JayaShravan_Assignment_1.ipynb)
#### Team Member 1
- Athista Vignesh P S
    - [Assignment 01](./Assignments/Team%20Member%201/Assignment-01/AthistaVignesh_Assignment_1.ipynb)
    - [Assignment 02](./Assignments/Team%20Member%201/Assignment-02/AthistaVignesh_Assignment_2.ipynb)
#### Team Member 2
- Bharath Kumar K
    - [Assignment 01](.)
#### Team Member 3
- Bharathwaj M V
    - [Assignment 01](.)

---

### Project Design & Planning :
- Ideation Phase
    - [Empathy Map](./Project%20Design%20%26%20Planning/Ideation%20Phase/Empathy%20Map.pdf)
    - [Literature Survey](./Project%20Design%20%26%20Planning/Ideation%20Phase/Literature%20Survey%20University%20predictor.pdf)
    - [Ideation](./Project%20Design%20%26%20Planning/Ideation%20Phase/Ideate.pdf)
    - [Problem Statement](./Project%20Design%20%26%20Planning/Ideation%20Phase/Problem%20Statement.pdf)
- Project Design Phase 1
- Project Design Phase 2
- Project Planning

---